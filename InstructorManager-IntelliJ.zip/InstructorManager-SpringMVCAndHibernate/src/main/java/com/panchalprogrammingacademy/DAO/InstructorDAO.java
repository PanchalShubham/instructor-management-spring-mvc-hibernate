package com.panchalprogrammingacademy.DAO;

import com.panchalprogrammingacademy.entity.Instructor;

import java.util.List;

// DAO stands for Data Access Object
public interface InstructorDAO {

    // fetches the list of instructors
    public List<Instructor> getInstructors() throws Exception;

    // adds the instructor to database
    public boolean addInstructor(Instructor instructor) throws Exception;

    // searches for the instructor with given id
    public Instructor getInstructorById(int id) throws Exception;

    // update the details of the instructor
    public void updateInstructor(Instructor instructor) throws Exception;

    // delete the instructor with given id from database
    public boolean deleteInstructorById(int id) throws Exception;
}
