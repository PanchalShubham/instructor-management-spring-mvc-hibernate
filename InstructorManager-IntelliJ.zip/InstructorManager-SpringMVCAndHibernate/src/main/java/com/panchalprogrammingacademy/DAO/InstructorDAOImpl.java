package com.panchalprogrammingacademy.DAO;

import com.panchalprogrammingacademy.entity.Instructor;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;


// applies to DAO implementation
@Repository
public class InstructorDAOImpl implements InstructorDAO{

    // inject the session factory
    @Autowired
    private SessionFactory sessionFactory;


    @Override
    public List<Instructor> getInstructors() throws Exception{
        // get the current hibernate session
        Session session = sessionFactory.getCurrentSession();

        // create a query
        Query<Instructor> query = session.createQuery("from Instructor order by name", Instructor.class);

        // execute query to get results and return back to caller
        return query.getResultList();
    }

    @Override
    public boolean addInstructor(Instructor instructor) throws Exception {
        // get the current hibernate session
        Session session = sessionFactory.getCurrentSession();

        // create query to search for instructor with given instructor name
        Query<Instructor> query = session.createQuery("from Instructor instructor where instructor.email = '" + instructor.getEmail() + "'", Instructor.class);

        // check and perform operation
        if(!query.getResultList().isEmpty())
            // email already taken
            return false;

        // save instructor
        session.save(instructor);

        // return true as we saved the instructor
        return true;
    }


    @Override
    public Instructor getInstructorById(int id) throws Exception {
        // get the current session
        Session session = sessionFactory.getCurrentSession();

        // create query
        Query<Instructor> query = session.createQuery("from Instructor instructor where instructor.id = " + id, Instructor.class);

        // execute query and fetch result
        List<Instructor> instructorList = query.getResultList();

        // validate and return result
        return (!instructorList.isEmpty() ? instructorList.get(0) : null);
    }

    @Override
    public void updateInstructor(Instructor instructor) throws Exception{
        // get the current session
        Session session = sessionFactory.getCurrentSession();

        // update the instructor
        session.update(instructor);
    }

    @Override
    public boolean deleteInstructorById(int id) throws Exception {
        // get the current session
        Session session = sessionFactory.getCurrentSession();

        // create query
        Query<Instructor> query = session.createQuery("from Instructor instructor where instructor.id = " + id, Instructor.class);

        // execute query and fetch result
        List<Instructor> instructorList = query.getResultList();

        // check if instructor with given id exist
        if (!instructorList.isEmpty()){
            System.out.println(instructorList);
            // delete the instructor
            session.delete(instructorList.get(0));
            // we deleted record so we return true
            return true;
        } else {
            // no instructor with given id found
            return false;
        }
    }
}
