package com.panchalprogrammingacademy.controller;

import com.panchalprogrammingacademy.entity.Instructor;
import com.panchalprogrammingacademy.service.InstructorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.Map;

// mapps to controller instructorController
@Controller
@RequestMapping("")
public class InstructorController {

    // inject the dependency for instructor service
    @Autowired
    private InstructorService instructorService;

    @GetMapping("/")
    public String home(ModelMap modelMap){
        try{
            // add attribute to model map
            modelMap.addAttribute("instructors", instructorService.getInstructors());
        } catch (Exception e){
            // add error message
            modelMap.addAttribute("error", "Failed to fetch instructor details from database!");
        }
        // render the instructor.jsp
        return "instructor";
    }


    @GetMapping("/add")
    public String addForm(ModelMap modelMap){
        // create a new instructor
        Instructor instructor = new Instructor();
        // add instructor to model
        modelMap.addAttribute("instructor", instructor);
        // create a new Map
        Map<String, String> departments = new HashMap<>();
        // add departments
        departments.put("CSE", "Computer Science and Engineering");
        departments.put("CHE", "Chemical Engineering");
        departments.put("CE", "Civil Engineering");
        departments.put("EE", "Electrical Engineering");
        departments.put("ME", "Mechanical Engineering");
        // update the departments attribute
        modelMap.addAttribute("departments", departments);
        // render the "add_instructor.jsp"
        return "add_instructor";
    }

    @PostMapping("/add")
    public String addInstructor(@ModelAttribute Instructor instructor, final RedirectAttributes redirectAttributes){
        try{
            // add instructor to list
            if (instructorService.addInstructor(instructor)){
                // add success message
                redirectAttributes.addFlashAttribute("success", "Instructor added successfully");
            } else {
                // add error message
                redirectAttributes.addFlashAttribute("error", "That email has already been taken!");
            }
        } catch (Exception e){
            // add error message
            redirectAttributes.addFlashAttribute("error", "Failed to save instructor details to database!");
        }
        // redirect to homepage
        return "redirect:/";
    }


    @GetMapping("/update")
    public String updateInstructor(@RequestParam(value="id") int id, ModelMap modelMap, final RedirectAttributes redirectAttributes){
        try{
            // search for the instructor with given id
            Instructor instructor = instructorService.getInstructorById(id);
            // validate search
            if (instructor != null){
                // add instructor to model
                modelMap.addAttribute("instructor", instructor);
                // create a new Map
                Map<String, String> departments = new HashMap<>();
                // add departments
                departments.put("CSE", "Computer Science and Engineering");
                departments.put("CHE", "Chemical Engineering");
                departments.put("CE", "Civil Engineering");
                departments.put("EE", "Electrical Engineering");
                departments.put("ME", "Mechanical Engineering");
                // update the departments attribute
                modelMap.addAttribute("departments", departments);
                // render "edit_instructor.jsp"
                return "edit_instructor";
            } else {
                // add error message
                redirectAttributes.addFlashAttribute("error", "Couldn't find that user");
                // redirect to homepage
                return "redirect:/";
            }
        } catch (Exception e){
            // add error message
            redirectAttributes.addFlashAttribute("error", "Failed to fetch instructor details form database!");
            // redirect to homepage
            return "redirect:/";
        }
    }

    @PostMapping("/update")
    public String updateInstructor(@ModelAttribute Instructor instructor, final RedirectAttributes redirectAttributes){
        try{
            // update the instructor
            instructorService.updateInstructor(instructor);
            // update success message
            redirectAttributes.addFlashAttribute("success", "Instructor details updated successfully");
            // redirect to home page
            return "redirect:/";
        } catch (Exception e){
            // add error message
            redirectAttributes.addFlashAttribute("error", "Failed to update details of instructor");
            // redirect to homepage
            return "redirect:/";
        }
    }

    @PostMapping("/delete/{id}")
    public String deleteInstructor(@PathVariable(value="id") int id, final RedirectAttributes redirectAttributes){
        try{
            // try to delete the instructor with given id
            if (instructorService.deleteInstructorById(id)){
                // instructor deleted successfully
                redirectAttributes.addFlashAttribute("success", "The instructor details you requested to delete has now been deleted!");
                // redirect to homepage
                return "redirect:/";
            } else {
                // no instructor with given id exist
                redirectAttributes.addFlashAttribute("error", "Couldn't find that instructor!");
                // redirect to homepage
                return "redirect:/";
            }
        } catch (Exception e){
            // add error message
            redirectAttributes.addFlashAttribute("error", "Failed to delete details of instructor");
            // redirect to homepage
            return "redirect:/";
        }
    }
}
