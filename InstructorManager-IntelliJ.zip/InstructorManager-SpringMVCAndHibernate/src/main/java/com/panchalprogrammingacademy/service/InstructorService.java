package com.panchalprogrammingacademy.service;

import com.panchalprogrammingacademy.entity.Instructor;

import java.util.List;

// service is like one place for all DAOs
public interface InstructorService {

    // fetch the list of instructors
    public List<Instructor> getInstructors() throws Exception;

    // add the instructor to database
    public boolean addInstructor(Instructor instructor) throws Exception;

    // searches for the instructor with given id
    public Instructor getInstructorById(int id) throws Exception;

    // update the details of the instructor
    public void updateInstructor(Instructor instructor) throws Exception;

    // deletes the instructor with given id
    public boolean deleteInstructorById(int id) throws Exception;

}
