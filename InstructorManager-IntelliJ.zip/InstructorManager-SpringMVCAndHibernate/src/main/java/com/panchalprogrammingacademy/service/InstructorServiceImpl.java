package com.panchalprogrammingacademy.service;

import com.panchalprogrammingacademy.DAO.InstructorDAO;
import com.panchalprogrammingacademy.entity.Instructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class InstructorServiceImpl implements InstructorService{
    // inject the customer DAO
    @Autowired
    private InstructorDAO instructorDAO;

    @Override
    @Transactional
    public List<Instructor> getInstructors() throws Exception{
        // get the list of instructors and send back to caller
        return instructorDAO.getInstructors();
    }

    @Override
    @Transactional
    public boolean addInstructor(Instructor instructor) throws Exception{
        // add instructor and return result
        return instructorDAO.addInstructor(instructor);
    }

    @Override
    @Transactional
    public Instructor getInstructorById(int id) throws Exception{
        // get the instructor by id
        return instructorDAO.getInstructorById(id);
    }

    @Override
    @Transactional
    public void updateInstructor(Instructor instructor) throws Exception{
        // update the details of the instructor
        instructorDAO.updateInstructor(instructor);
    }

    @Override
    @Transactional
    public boolean deleteInstructorById(int id) throws Exception {
        // delete the instructor with given id
        return instructorDAO.deleteInstructorById(id);
    }
}
