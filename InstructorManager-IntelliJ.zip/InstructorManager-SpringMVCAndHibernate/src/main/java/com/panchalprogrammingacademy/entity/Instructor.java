package com.panchalprogrammingacademy.entity;

import javax.persistence.*;

@Entity
@Table(name = "instructor")
public class Instructor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;
    @Column(name = "name")
    private String name;
    @Column(name = "email")
    private String email;
    @Column(name = "date_of_joining")
    private String dateOfJoining;
    @Column(name = "department")
    private String department;
    @Column(name = "bio")
    private String bio;

    // constructors
    public Instructor(){
    }
    public Instructor(String name, String email, String dateOfJoining, String department, String bio) {
        this.name = name;
        this.email = email;
        this.dateOfJoining = dateOfJoining;
        this.department = department;
        this.bio = bio;
    }

    // getter and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDateOfJoining() {
        return dateOfJoining;
    }

    public void setDateOfJoining(String dateOfJoining) {
        this.dateOfJoining = dateOfJoining;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getBio() {
        return bio;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    // override to string
    @Override
    public String toString() {
        return "Instructor{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", datOfJoining='" + dateOfJoining + '\'' +
                ", department='" + department + '\'' +
                ", bio='" + bio + '\'' +
                '}';
    }
}
